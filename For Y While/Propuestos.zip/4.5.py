ahorro_diario = 3 

total_ahorro_anual = 0

dias = 1




while dias <= 365:  

    total_ahorro_anual += ahorro_diario

    ahorro_diario += 3  

    dias += 1



ahorro_anual_pesos = total_ahorro_anual 



print(f"El ahorro total en centavos al cabo de un año es: {total_ahorro_anual} centavos")

print(f"El ahorro total en pesos al cabo de un año es: ${ahorro_anual_pesos:.2f}")
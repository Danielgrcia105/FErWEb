N = int(input("Ingrese la cantidad de focos en el lote: "))



focos_verdes = 0

focos_blancos = 0

focos_rojos = 0

 
contador = 0

while contador < N:

    color_foco = input("Ingrese el color del foco (verde, blanco, rojo): ").lower()

    

    if color_foco == "verde":

        focos_verdes += 1

    elif color_foco == "blanco":

        focos_blancos += 1

    elif color_foco == "rojo":

        focos_rojos += 1

    else:

        print("Color de foco no válido. Use verde, blanco o rojo.")

    

    contador += 1

 

print(f"Número de focos verdes: {focos_verdes}")
print(f"Número de focos blancos: {focos_blancos}")
print(f"Numero de focos rojos: {focos_rojos}")

print ("orden de focos verde, blanco, rojo")
print(f"Número de focos: {focos_verdes,focos_blancos,focos_rojos}")
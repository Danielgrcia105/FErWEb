N = int(input("Ingrese la cantidad de artículos que desea adquirir: "))

 

costo_total = 0




contador = 0

while contador < N:

    precio = float(input(f"Ingrese el precio del artículo {contador + 1}: "))

    

    if precio >= 200:

        descuento = 0.15 * precio

    elif precio > 100 and precio < 200:

        descuento = 0.12 * precio

    else:

        descuento = 0.10 * precio

 

    costo = precio - descuento

    costo_total += costo

    

    print(f"Para el artículo {contador + 1}:")

    print(f"Precio: ${precio:.2f}")

    print(f"Descuento: ${descuento:.2f}")

    print(f"Costo final: ${costo:.2f}")

    

    contador += 1

 
print(f"El costo total de los {N} artículos es: ${costo_total:.2f}")
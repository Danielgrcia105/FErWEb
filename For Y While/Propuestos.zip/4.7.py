N = int(input("Ingrese la cantidad de años para calcular la inversión: "))

deposito_mensual = float(input("Ingrese la cantidad de pesos que deposita mensualmente: "))
 

inversion_inicial = 0.0


año_actual = 1



while año_actual <= N:

    interes_anual = 0.10  

    inversion_anual = inversion_inicial

    

    for mes in range(12):

        inversion_anual += deposito_mensual

        inversion_anual *= (1 + interes_anual / 12) 

    

    print(f"Inversión final en el año {año_actual}: ${inversion_anual:.2f}")

    

    inversion_inicial = inversion_anual  

    año_actual += 1
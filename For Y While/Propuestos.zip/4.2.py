costo_simple = 20

costo_doble = 25

costo_triple = 28

 

porcentaje_cargo = 0.05




costo_total = 0


n = int(input("Ingrese la cantidad de hamburguesas que desea comprar: "))


contador = 0


while contador < n:

    tipo_hamburguesa = input("Ingrese el tipo de hamburguesa (S para sencilla, D para doble, T para triple): ")

    

    if tipo_hamburguesa == "S":

        costo_total += costo_simple

    elif tipo_hamburguesa == "D":

        costo_total += costo_doble

    elif tipo_hamburguesa == "T":

        costo_total += costo_triple

    else:

        print("Tipo de hamburguesa no válido. Use S, D o T.")

        continue

    
    contador += 1


cargo_por_tarjeta = costo_total * porcentaje_cargo


costo_total_con_cargo = costo_total + cargo_por_tarjeta


print("El costo total de las hamburguesas es: $", costo_total)

print("El costo total con el 5% de cargo por tarjeta de crédito es: $", costo_total_con_cargo)
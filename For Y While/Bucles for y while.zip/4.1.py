# Se requiere iniciar una variable esto con el fin de almacenar una operacion
suma = 0

# aplicamos el ciclo en 10 acntidades 
for i in range(10):
    #usamnos range para marar un limite en este caso el limite sera 10 valores 
    # pedimos al "usuario" un valor  para convertirlo en un entero
    cantidad = int(input("Ingrese una cantidad: "))
    
    # Hacemos la operacion (Suma) con la cantidad del usario ingresada
    suma += cantidad

# Por ultimo imprimimos el resultado 
print("La suma de las diez cantidades es:", suma)

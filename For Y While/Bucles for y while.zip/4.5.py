#variable
C = 0
SU = 0
NU = int(input("Ingrese alumnos: "))

# iniciamos bucle para leer las edades y poder realizar la operacion
while C < NU:
    ED = int(input(f"Ingrese edad de alumno {C + 1}: "))
    SU += ED
    C += 1
#en el bucle estamos indicando la operacion o variables que queremos sumar
#  realizamos la operacion (calculamos el promedio)
PR = SU / NU

# por ultimo imprimimos el resultado
print(f"La edad promedio de los {NU} alumnos es: {PR}")
#de misma manera utilizamos f esto con el fin de realizar una cadena y poder sustituir los valors que estan en llave
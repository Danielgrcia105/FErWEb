# iniciamos con las variables 
C = 0
SU = 0
NU = int(input("Ingrese el número de alumnos: "))

# iniciamos bucle para leer las edades y poder realizar la operacion
for C < NU:
    ED = int(input(f"Ingrese la edad del alumno {C + 1}: "))
    SU += ED
    C += 1

#  realizamos la operacion (calculamos el promedio)
PR = SU / NU

# por ultimo imprimimos el resultado
print(f"La edad promedio de los {NU} alumnos es: {PR}")
#de misma manera utilizamos f esto con el fin de realizar una cadena y poder sustituir los valors que estan en llave
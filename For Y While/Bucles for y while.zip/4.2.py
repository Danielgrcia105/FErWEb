# Inicializar la variable de suma (SU)
SU = 0

# en esta parte se inicia el contador con la variable (c)
C = 1

# hacemos que se repita el proceso hasta que c sea mayor que 10
while C <= 10:
    # Leer el valor ingresado por el usuario (VA) y convertirlo a un número entero
    VA = int(input("Ingrese un valor: "))
    
    # Sumar el valor ingresado a la suma acumulada (SU)
    SU = SU + VA
    
    # Incrementar el contador (C) en 1
    C = C + 1

# Imprimir el resultado de la suma
print("La suma de los diez valores ingresados es:", SU)

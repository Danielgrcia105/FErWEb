# Iniciamos la variable de sumas (SU)
SU = 0

# utilizamos el bucle  "for" para poder repetir la lectura y sumar 10 veces
for C in range(1, 11):
    # 
    # Leemos el valor ingresado por el usuario  (VA) y lo concertimos a numero entero
    VA = int(input("Ingrese un valor: "))
    
    # sumamos el valor ingresado a la suma acumulada (SU)
    SU = SU + VA

# por ultimo imprimimos el valor o rerultaedo de la suma
print("La suma de los diez valores ingresados es:", SU)
